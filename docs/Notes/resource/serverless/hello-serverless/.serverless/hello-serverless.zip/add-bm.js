'use strict';

module.exports.add = async (event) => {
  const { num1, num2 } = event;
  console.log('num1 ', num1)
  console.log('num2 ', num2)
  return num1 + num2;
};
